#include <iostream>
#include <fstream>
#include <chrono>
#include <cstdlib>
#include <string>
#include "qsort.h"
#include "rflist.h"

using namespace std;

//built in follow along to this video https://www.youtube.com/watch?v=2_3fR-k-LzI by Coding Jesus "C++ Hash Table Implementation"
class HashTable {
    private:
        static const int hashGroups = 10;

};
